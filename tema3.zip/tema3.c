#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
typedef struct Node {
    int vertex;
    int cost; // Weight or cost of the edge
    struct Node* next;
} Node;

typedef struct Graph {
    int numVertices;
    struct Node** adjLists;
    int* visited;
} Graph;

struct Node* createNode(int v, int cost) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->vertex = v;
    newNode->cost = cost;
    newNode->next = NULL;
    return newNode;
}

struct Graph* createGraph(int vertices) {
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->numVertices = vertices;
    graph->adjLists = (struct Node**)malloc(vertices * sizeof(struct Node*));
    graph->visited = (int*)malloc(vertices * sizeof(int));

    for (int i = 0; i < vertices; i++) {
        graph->adjLists[i] = NULL;
        graph->visited[i] = 0;
    }

    return graph;
}

void addEdge(struct Graph* graph, int src, int dest, int cost) {
    struct Node* newNode = createNode(dest, cost);
    newNode->next = graph->adjLists[src];
    graph->adjLists[src] = newNode;
	//printf("adj = %d\n", graph->adjLists[src]->vertex);

    newNode = createNode(src, cost);
    newNode->next = graph->adjLists[dest];
    graph->adjLists[dest] = newNode;
}

void DFS(struct Graph* graph, int vertex) {
    struct Node* adjList = graph->adjLists[vertex];
    struct Node* temp = adjList;
	// printf("temp = %d\n", temp->vertex);

    graph->visited[vertex] = 1;

    while (temp != NULL) {
        int connectedVertex = temp->vertex;

        if (graph->visited[connectedVertex] == 0) {
            DFS(graph, connectedVertex);
        }

        temp = temp->next;
    }
}




int countComponents(struct Graph* graph, int *arrayForStartVertex) {
    int numComponents = 0;
	int idx = 0;
	// printf("grapf->num = %d\n", graph->numVertices);
    for (int i = 0; i < graph->numVertices; i++) {
        if (graph->visited[i] == 0) {
			arrayForStartVertex[idx++] = i;
            DFS(graph, i);
			// for (int j = 0 ; j < graph->numVertices; j++) {
			// 	printf("%d ", graph->visited[j]);
			// }
			// printf("\n");
            numComponents++;
            // printf("we increment nrcomponents\n");
        }
    }
  
    return numComponents;
}




void calculateMinimumCost(struct Graph* graph, int* arrayForStartVertex, int numComponents) {
    for (int i = 0; i < numComponents; i++) {
        int startVertex = arrayForStartVertex[i];

        // Mark all vertices as unvisited
        for (int j = 0; j < graph->numVertices; j++) {
            graph->visited[j] = 0;
        }

        // Perform DFS on the current component
        DFS(graph, startVertex);

        // Calculate the minimum cost path for the current component
        int minCost = INT_MAX;

        for (int vertex = 0; vertex < graph->numVertices; vertex++) {
            if (graph->visited[vertex] == 1) {
                struct Node* adjList = graph->adjLists[vertex];
                int componentCost = 0;

                while (adjList != NULL) {
                    if (graph->visited[adjList->vertex] == 1) {
                        componentCost += adjList->cost;
                    }

                    adjList = adjList->next;
                }

                if (componentCost < minCost) {
                    minCost = componentCost;
                }
            }
        }

        printf("Minimum cost for Component %d (Start vertex: %d): %d\n", i, startVertex, minCost);
    }
}



int main(int argv, char *argc[]) {
    if(atoi(argc[1]) == 1) {
    FILE* inputFile = fopen("tema3.in", "r");
    if (inputFile == NULL) {
        printf("Failed to open the input file.\n");
        return 1;
    }

    int vertices, edges;
    fscanf(inputFile, "%d %d", &vertices, &edges);
	// printf("edges = %d\n", edges);

    struct Graph* graph = createGraph(vertices);

    int src;
	int dest;
	int index = 0;
	int ok = 0;
	char *srcString = malloc(100);
	char *destString = malloc(100);
	char **array;
	array = malloc(10000);
    int i, cost;
	//printf("edges = %d\n", edges);
    for (i = 0; i < edges; i++) {
		ok = 0;
		//printf("edge = %d\ni = %d\n",edges, i);
        fscanf(inputFile, "%s", srcString);
        fscanf(inputFile, "%s", destString);
		for (int j = 0; j < index; j++) {
			if (strcmp(array[j], srcString) == 0) {
				src = j;
				ok = 1;
				break;
			}
		}
		if (ok == 0) {
			src = index;
			array[index] = malloc(100);
			strcpy(array[index], srcString);
			index++;
		}
		ok = 0;
		for (int j = 0; j < index; j++) {
			if (strcmp(array[j], destString) == 0) {
				dest = j;
				ok = 1;
				break;
			}
		}
		if (ok == 0) {
			dest = index;
			array[index] = malloc(100);
			strcpy(array[index], destString);
			index++;
		}

        fscanf(inputFile, "%d", &cost);
        addEdge(graph, src, dest, cost);
		
		//printf("sunt in for\n");
    }



    fclose(inputFile);

    int startVertex = 0;
    //DFS(graph, startVertex);
	int *arrayForStartVertex = malloc(vertices * sizeof(int));
    int numComponents = countComponents(graph, arrayForStartVertex);
	calculateMinimumCost(graph, arrayForStartVertex, numComponents);
	for (int j = 0; j < numComponents; j++) {
		printf("Start vertex for component %d is %d\n", j, arrayForStartVertex[j]);
	}
    FILE* outputFile = fopen("tema3.out", "w");
    if (outputFile == NULL) {
        printf("Failed to open the output file.\n");
        return 1;
    }
	printf("Numarul de componente = %d\n", numComponents);
    fprintf(outputFile, "%d\n", numComponents);
    fclose(outputFile);

    return 0;
}
}